import { useEffect, useState } from "react";
import { useRouterState } from "@tanstack/react-router";

export function FlashTransition() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [key, setKey] = useState(0);

  useEffect(() => {
    setKey((k) => k + 1);
  }, [pathname]);

  return (
    <div
      key={key}
      aria-hidden
      className="route-flash pointer-events-none fixed inset-0 z-50"
      style={{
        background:
          "radial-gradient(circle at 50% 42%, color-mix(in oklab, white 92%, var(--color-glow)) 0%, color-mix(in oklab, var(--color-glow) 78%, white) 14%, color-mix(in oklab, var(--color-glow) 42%, transparent) 38%, transparent 76%)",
      }}
    />
  );
}
