export function BulbMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`bulb-mark ${compact ? "bulb-mark-compact" : ""}`} aria-hidden="true">
      <svg viewBox="0 0 320 360" role="presentation">
        <g className="bulb-construction">
          <circle cx="160" cy="238" r="92" />
          <circle cx="160" cy="238" r="122" />
          <path d="M38 238h244M160 116v244M74 152l172 172M246 152 74 324" />
          <path d="M246 176h44M268 154v44M30 302h42M51 281v42" />
        </g>
        <g className="bulb-pendant">
          <path className="bulb-cord" d="M160 0v116" />
          <path className="bulb-socket" d="M149 116h22v15h-22zM146 131h28v15h-28z" />
          <path className="bulb-drawing" d="M160 146c-29 0-53 23-53 53 0 22 9 34 19 47 7 9 10 16 10 28h48c0-12 3-19 10-28 10-13 19-25 19-47 0-30-24-53-53-53Z" />
          <path className="bulb-drawing" d="M136 286h48M140 297h40M147 308h26" />
          <path className="bulb-filament" d="M143 200c6 11 12 16 17 16s11-5 17-16M160 216v42" />
        </g>
        <g className="bulb-notes">
          <text x="24" y="28">LIGHT / 01</text>
          <text x="246" y="336">90°</text>
          <text x="20" y="336">LUM</text>
        </g>
      </svg>
    </div>
  );
}
